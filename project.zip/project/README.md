SHIFT ORGANISER
#### Video Demo:  https://youtu.be/fYP_M1kmt9c
#### Description: Shift Organiser.

Shifts organiser for simpe cooperating managers and employees help to create schedule of the shifts for working week/

written by Lioubov Zolotchevsky Tel Aviv, Israel 2021 31 12 